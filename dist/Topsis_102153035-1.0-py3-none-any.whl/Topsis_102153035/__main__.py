from Topsis_102153035.Topsis_102153035 import main

if __name__ == "__main__":
    main()
